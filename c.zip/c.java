import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class Calculator extends Applet implements ActionListener{
    Label l1, l2, l3;
    TextField t1, t2, t3;
    Button add1, sub, mul, div;
    
    public void init() {
        l1 = new Label("Enter 1st no.:");
        add(l1);
        t1 = new TextField(10);
        add(t1);
        l2 = new Label("Enter 2nd no.:");
        add(l2);
        t2 = new TextField(10);
        add(t2);
        l3 = new Label("Result:        ");
        add(l3);        
        t3 = new TextField(10);
        add(t3);
        add1 = new Button("+");
        sub = new Button("-");
        mul = new Button("*");
        div = new Button("/");
        add(add1);
        add(sub);
        add(mul);
        add(div);
        
        add1.addActionListener(this);
        sub.addActionListener(this);
        mul.addActionListener(this);
        div.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent ae) {
        int num1 = Integer.parseInt(t1.getText());
        int num2 = Integer.parseInt(t2.getText());
        String a = ae.getActionCommand();
        
        if(a.equals("+")) {
            t3.setText(String.valueOf(num1 + num2));
        } else if(a.equals("-")) {
            t3.setText(String.valueOf(num1 - num2));
        } else if(a.equals("*")) {
            t3.setText(String.valueOf(num1 * num2));
        } else if(a.equals("/")) {
            if(num2 == 0)
                t3.setText("Not Defined");
            else 
                t3.setText(String.valueOf(num1 / num2));
        }
    }

}
